#ifndef SPI_MOTOR_H_
#define SPI_MOTOR_H_

#ifdef __cplusplus 
extern "C" { 
#endif

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <linux/types.h>

/*
 * TX to motor data message
 */
typedef struct {
  float q[12];
  float qd[12];
  float tau[12];
} motor_data_t;

/*
 * RX from motor command message
 */
typedef struct {
  float q_des[12];
  float qd_des[12];
  float kp[12];
  float kd[12];
  float tau_ff[12];
} motor_command_t;

/*
 * return 0 success; 
 * return -1 fail;
 */ 

extern int motor_init(void);
extern void motor_uninit(void);
extern motor_command_t *get_motor_cmd(void);
extern motor_data_t *get_motor_data(void);
extern int set_motor_cmd(motor_command_t *cmd);
extern int set_motor_enable_cmd(int enable, int index);
extern int motor_debug_out_set(int enable);

/*
 * Support firmware upgrade for motors
 */
extern int update_motor_fw_cmd(char *file, int index);

extern int set_motor_zero_cmd(int index);

/*
 * char motor_ver[52];
 */

extern int get_motor_ver_cmd(char *ver, uint8_t index, uint8_t type);

#ifdef __cplusplus 
};
#endif

#endif
